﻿// GEN BLOCK BEGIN Include
#define TSMP_IMPL
#include "TSMaster.h"
#include "MPLibrary.h"
#include "Database.h"
#include "TSMasterBaseInclude.h"
#include "Configuration.h"
// GEN BLOCK END Include

// CODE BLOCK BEGIN Variable CAN7C1 MCwwLCw_
// 变量文档 "CAN7C1"
TMPVarInt CAN7C1;
// CODE BLOCK END Variable CAN7C1

// CODE BLOCK BEGIN Variable MCU_Version MiwwLCw_
// 变量文档 "MCU_Version"
TMPVarString MCU_Version;
// CODE BLOCK END Variable MCU_Version

// CODE BLOCK BEGIN Variable DSP_Version MiwwLCw_
// 变量文档 "DSP_Version"
TMPVarString DSP_Version;
// CODE BLOCK END Variable DSP_Version

// GEN BLOCK BEGIN Custom_Function
s32 MakeCheckSum_0xF8(const pu8 AData, const u8 ALen);
s32 MakeCheckSum_0xFC(const pu8 AData, const u8 ALen);
// GEN BLOCK END Custom_Function

// CODE BLOCK BEGIN On_CAN_PreTx NewOn_CAN_PreTx_0xF8 MCwtMSwyNDg_
// CAN报文预发送事件 "NewOn_CAN_PreTx_0xF8" 针对标识符 = 0xF8
void on_can_pretx_NewOn_CAN_PreTx_0xF8(const PCAN ACAN) { try {  // 针对标识符 = 0xF8
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel
THCU_1_6_1 HCU_1_6_1;
HCU_1_6_1.init(); // 在使用此结构体前调用这段初始化代码
HCU_1_6_1.FCAN = *ACAN; // 若是在回调函数中，请用ACAN数据赋值FCAN
// deal with signals using HCU_1_6_1.XXX

//HCU_1_6_1.Checksum_HCU_1_6=ACAN->FCAN[1]^ACAN->FCAN[2]^ACAN->FCAN[3]^ACAN->FCAN[4]^ACAN->FCAN[5]^ACAN->FCAN[6]^ACAN->FCAN[7];
//HCU_1_6_1.Checksum_HCU_1_6=9;
HCU_1_6_1.Checksum_HCU_1_6=MakeCheckSum_0xF8(&HCU_1_6_1.FCAN.FData[0], 8); 
*ACAN = HCU_1_6_1.FCAN;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_PreTx NewOn_CAN_PreTx_0xF8

// CODE BLOCK BEGIN On_CAN_PreTx NewOn_CAN_PreTx_0xFC MCwtMSwyNTI_
// CAN报文预发送事件 "NewOn_CAN_PreTx_0xFC" 针对标识符 = 0xFC
void on_can_pretx_NewOn_CAN_PreTx_0xFC(const PCAN ACAN) { try {  // 针对标识符 = 0xFC
TEEM_2_1 EEM_2_1;
EEM_2_1.init(); // 在使用此结构体前调用这段初始化代码
EEM_2_1.FCAN = *ACAN; // 若是在回调函数中，请用ACAN数据赋值FCAN
// deal with signals using EEM_2_1.XXX
EEM_2_1.Checksum_EEM_2=MakeCheckSum_0xFC(&EEM_2_1.FCAN.FData[0], 8); 
*ACAN = EEM_2_1.FCAN;
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_PreTx NewOn_CAN_PreTx_0xFC

// CODE BLOCK BEGIN Custom_Function MakeCheckSum_0xF8 Y29uc3QgcHU4IEFEYXRhLCBjb25zdCB1OCBBTGVu
// 自定义函数 "MakeCheckSum_0xF8"
s32 MakeCheckSum_0xF8(const pu8 AData, const u8 ALen) { try { // 自定义函数: 
 // return IDX_ERR_OK;
u8 crc = 0x11; 
u8 byte_index; 
u8 bit_index;
// CRC8 demo 

crc = *(AData + 1)^*(AData + 2)^*(AData + 3)^*(AData + 4)^*(AData + 5)^*(AData + 6)^*(AData + 7)+0x10;	
//crc =    *(AData + 7);
return crc;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); return(IDX_ERR_MP_CODE_CRASH); }}
// CODE BLOCK END Custom_Function MakeCheckSum_0xF8

// CODE BLOCK BEGIN Custom_Function MakeCheckSum_0xFC Y29uc3QgcHU4IEFEYXRhLCBjb25zdCB1OCBBTGVu
// 自定义函数 "MakeCheckSum_0xFC"
s32 MakeCheckSum_0xFC(const pu8 AData, const u8 ALen) { try { // 自定义函数: 
 // return IDX_ERR_OK;
u8 crc = 0x11; 
u8 byte_index; 
u8 bit_index;
// CRC8 demo 

crc = *(AData + 1)^*(AData + 2)^*(AData + 3)^*(AData + 4)^*(AData + 5)^*(AData + 6)^*(AData + 7)+0x10;	
//crc =    *(AData + 7);
return crc;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); return(IDX_ERR_MP_CODE_CRASH); }}
// CODE BLOCK END Custom_Function MakeCheckSum_0xFC

// CODE BLOCK BEGIN On_Var_Change On_Read_Version Q0FON0MxLC0x
// 变量变化事件 "On_Read_Version" 针对变量 "CAN7C1" [On Written]
void on_var_change_On_Read_Version(void) { try { // 变量 = CAN7C1

//   TCAN c;
//   c.init_w_std_id(0x7C1, 8);
//  // c={0x01,0x02,0x02,0x02,0x02,0x02,0x02,0x02};
//   com.transmit_can_async(&c);
//   CAN7C1.set(0);
TCAN c;
//c.FIdxChn1=0;
// c.FProperties=0x1;
// c.FDLC=8;
// c.FIdentifier=0x7C1;
c.init_w_std_id(0x7C1, 8);

c.FData[0]=0x03;
c.FData[1]=0x22;
c.FData[2]=0xF1;
c.FData[3]=0x94;
c.FData[4]=0x00;
c.FData[5]=0x00;
c.FData[6]=0x00;
c.FData[7]=0x00;
com.transmit_can_async(&c);
app.wait(20,"waiting");
c.FData[0]=0x30;
c.FData[1]=0x00;
c.FData[2]=0x14;
c.FData[3]=0x00;
c.FData[4]=0x00;
c.FData[5]=0x00;
c.FData[6]=0x00;
c.FData[7]=0x00;

com.transmit_can_async(&c);


} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_Var_Change On_Read_Version

// CODE BLOCK BEGIN On_CAN_Rx CAN7C9 MCwtMSwxOTkz
// CAN报文接收事件 "CAN7C9" 针对标识符 = 0x7C9
void on_can_rx_CAN7C9(const TCAN* ACAN) { try {  // 针对标识符 = 0x7C9
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel
char a[4];
char b[8];

 if(ACAN->FData[0]==0x10&&ACAN->FData[1]==0x13&&ACAN->FData[2]==0x62&&ACAN->FData[3]==0xF1&&ACAN->FData[4]==0x94)
 {
 a[0]=(ACAN->FData[5]&0x0F)+0x30;
 a[1]=(ACAN->FData[6]&0x0F)+0x30;
 a[2]=(ACAN->FData[7]&0x0F)+0x30;
 a[3]='\0';
 MCU_Version.set(a);
//MCU_Version.set((ACAN->FData[7]&0x0F));
 }
 
   if(ACAN->FData[0]==0x21)
 {
//a=(ACAN->FData[1]&0x0F)*1000000+(ACAN->FData[2]&0x0F)*100000+(ACAN->FData[3]&0x0F)*10000+(ACAN->FData[4]&0x0F)*1000+(ACAN->FData[5]&0x0F)*100+(ACAN->FData[6]&0x0F)*10+(ACAN->FData[7]&0x0F);
  b[0]=(ACAN->FData[1]&0x0F)+0x30;
 b[1]=(ACAN->FData[2]&0x0F)+0x30;
  b[2]=(ACAN->FData[3]&0x0F)+0x30;
   b[3]=(ACAN->FData[4]&0x0F)+0x30;
    b[4]=(ACAN->FData[5]&0x0F)+0x30;
     b[5]=(ACAN->FData[6]&0x0F)+0x30;
      b[6]=(ACAN->FData[7]&0x0F)+0x30;
      b[7]='\0';  
DSP_Version.set(b);
 }

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_Rx CAN7C9

// CODE BLOCK BEGIN Step_Function  NQ__
// 主step函数，执行周期 5 ms
void step(void) { try { // 周期 = 5 ms

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END Step_Function 

