﻿#include "TSMasterBaseInclude.h"

DLLEXPORT void __stdcall write_api_document_auto(const void* AOpaque, const TWriteAPIDocumentFunc AAPIFunc, const TWriteAPIParaFunc AParaFunc){
  AAPIFunc(AOpaque, "MakeCheckSum_0xF8", "CCode900", "", "", 2);
  AParaFunc(AOpaque, 0, "MakeCheckSum_0xF8", "AData", true, "pu8", "");
  AParaFunc(AOpaque, 1, "MakeCheckSum_0xF8", "ALen", true, "u8", "");
  AAPIFunc(AOpaque, "MakeCheckSum_0xFC", "CCode900", "", "", 2);
  AParaFunc(AOpaque, 0, "MakeCheckSum_0xFC", "AData", true, "pu8", "");
  AParaFunc(AOpaque, 1, "MakeCheckSum_0xFC", "ALen", true, "u8", "");
}
