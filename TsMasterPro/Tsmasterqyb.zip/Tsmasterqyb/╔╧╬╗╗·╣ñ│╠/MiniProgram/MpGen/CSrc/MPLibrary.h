﻿#ifndef _MPLIBRARY_H
#define _MPLIBRARY_H
#include "TSMasterBaseInclude.h"
#pragma pack(push)
#pragma pack(1)

#pragma pack(pop)
#endif
