﻿// Configuration Parameters Header

// Please set "Auto Generate Const in C Code" option in constant manager to auto generate constant definitions
