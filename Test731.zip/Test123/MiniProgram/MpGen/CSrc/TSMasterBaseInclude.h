﻿#ifndef __TSMASTER_BASE_INCLUDE
#define __TSMASTER_BASE_INCLUDE

#include "TSMaster.h"

#endif
