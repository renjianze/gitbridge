%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calibration file for SWC: SwcDCDC_FaultConfirm
% Author: XuDong
% Project: E001
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%try
	% External enumeration types
	%SwcDCDC_FaultConfirm_defineIntEnumTypes;
	
%catch
%end

%% CALPRM Parameters and AUTOSAR datatypes
path = pwd;
clear;
load("SwcDCDC_FaultConfirm_calprm.mat");

%% Add here the local constants of the model (as simulink parameters)
U8_DCDC_CMD_Work_NoEnable=Simulink.Parameter;
U8_DCDC_CMD_Work_NoEnable.Value = 0;
U8_DCDC_CMD_Work_NoEnable.DataType = "uint8";
U8_DCDC_CMD_Work_NoEnable.CoderInfo.StorageClass = 'Custom';
U8_DCDC_CMD_Work_NoEnable.CoderInfo.CustomStorageClass = "Default";

U8_DCDC_CMD_Work_PreChrgEnable=Simulink.Parameter;
U8_DCDC_CMD_Work_PreChrgEnable.Value = 1;
U8_DCDC_CMD_Work_PreChrgEnable.DataType = "uint8";
U8_DCDC_CMD_Work_PreChrgEnable.CoderInfo.StorageClass = 'Custom';
U8_DCDC_CMD_Work_PreChrgEnable.CoderInfo.CustomStorageClass = "Default";

U8_DCDC_CMD_Work_BuckEnable=Simulink.Parameter;
U8_DCDC_CMD_Work_BuckEnable.Value = 2;
U8_DCDC_CMD_Work_BuckEnable.DataType = "uint8";
U8_DCDC_CMD_Work_BuckEnable.CoderInfo.StorageClass = 'Custom';
U8_DCDC_CMD_Work_BuckEnable.CoderInfo.CustomStorageClass = "Default";

U8_Dsp_TxPcbOutVolt1PrecisionFactor=Simulink.Parameter;
U8_Dsp_TxPcbOutVolt1PrecisionFactor.Value = 10;
U8_Dsp_TxPcbOutVolt1PrecisionFactor.DataType = "uint8";
U8_Dsp_TxPcbOutVolt1PrecisionFactor.CoderInfo.StorageClass = 'Custom';
U8_Dsp_TxPcbOutVolt1PrecisionFactor.CoderInfo.CustomStorageClass = "Default";

U8_Kl30_DSPLimit=Simulink.Parameter;
U8_Kl30_DSPLimit.Value = 15;
U8_Kl30_DSPLimit.DataType = "uint8";
U8_Kl30_DSPLimit.CoderInfo.StorageClass = 'Custom';
U8_Kl30_DSPLimit.CoderInfo.CustomStorageClass = "Default";

U8_Kl30_DSPLimit2=Simulink.Parameter;
U8_Kl30_DSPLimit2.Value = 10;
U8_Kl30_DSPLimit2.DataType = "uint8";
U8_Kl30_DSPLimit2.CoderInfo.StorageClass = 'Custom';
U8_Kl30_DSPLimit2.CoderInfo.CustomStorageClass = "Default";

U16_DCDC_FaultConfirmDelayTime=Simulink.Parameter;
U16_DCDC_FaultConfirmDelayTime.Value = 5000;
U16_DCDC_FaultConfirmDelayTime.DataType = "uint16";
U16_DCDC_FaultConfirmDelayTime.CoderInfo.StorageClass = 'Custom';
U16_DCDC_FaultConfirmDelayTime.CoderInfo.CustomStorageClass = "Default";

U8_IPCF_AgingMode=Simulink.Parameter;
U8_IPCF_AgingMode.Value = 1;
U8_IPCF_AgingMode.DataType = "uint8";
U8_IPCF_AgingMode.CoderInfo.StorageClass = 'Custom';
U8_IPCF_AgingMode.CoderInfo.CustomStorageClass = "Default";
%% Load AUTOSAR memory section for code generatiom