﻿// GEN BLOCK BEGIN Include
#define TSMP_IMPL
#include "TSMaster.h"
#include "MPLibrary.h"
#include "Database.h"
#include "TSMasterBaseInclude.h"
#include "Configuration.h"
// GEN BLOCK END Include

// GEN BLOCK BEGIN Custom_Function
s32 MakeCheckSum_0xF8(const pu8 AData, const u8 ALen);
s32 MakeCheckSum_0xFC(const pu8 AData, const u8 ALen);
// GEN BLOCK END Custom_Function

// CODE BLOCK BEGIN On_CAN_PreTx NewOn_CAN_PreTx_0xF8 MCwtMSwyNDg_
// CAN报文预发送事件 "NewOn_CAN_PreTx_0xF8" 针对标识符 = 0xF8
void on_can_pretx_NewOn_CAN_PreTx_0xF8(const PCAN ACAN) { try {  // 针对标识符 = 0xF8
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel
THCU_1_6_1 HCU_1_6_1;
HCU_1_6_1.init(); // 在使用此结构体前调用这段初始化代码
HCU_1_6_1.FCAN = *ACAN; // 若是在回调函数中，请用ACAN数据赋值FCAN
// deal with signals using HCU_1_6_1.XXX

//HCU_1_6_1.Checksum_HCU_1_6=ACAN->FCAN[1]^ACAN->FCAN[2]^ACAN->FCAN[3]^ACAN->FCAN[4]^ACAN->FCAN[5]^ACAN->FCAN[6]^ACAN->FCAN[7];
//HCU_1_6_1.Checksum_HCU_1_6=9;
HCU_1_6_1.Checksum_HCU_1_6=MakeCheckSum_0xF8(&HCU_1_6_1.FCAN.FData[0], 8); 
*ACAN = HCU_1_6_1.FCAN;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_PreTx NewOn_CAN_PreTx_0xF8

// CODE BLOCK BEGIN On_CAN_PreTx NewOn_CAN_PreTx_0xFC MCwtMSwyNTI_
// CAN报文预发送事件 "NewOn_CAN_PreTx_0xFC" 针对标识符 = 0xFC
void on_can_pretx_NewOn_CAN_PreTx_0xFC(const PCAN ACAN) { try {  // 针对标识符 = 0xFC
TEEM_2_1 EEM_2_1;
EEM_2_1.init(); // 在使用此结构体前调用这段初始化代码
EEM_2_1.FCAN = *ACAN; // 若是在回调函数中，请用ACAN数据赋值FCAN
// deal with signals using EEM_2_1.XXX
EEM_2_1.Checksum_EEM_2=MakeCheckSum_0xFC(&EEM_2_1.FCAN.FData[0], 8); 
*ACAN = EEM_2_1.FCAN;
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_PreTx NewOn_CAN_PreTx_0xFC

// CODE BLOCK BEGIN Custom_Function MakeCheckSum_0xF8 Y29uc3QgcHU4IEFEYXRhLCBjb25zdCB1OCBBTGVu
// 自定义函数 "MakeCheckSum_0xF8"
s32 MakeCheckSum_0xF8(const pu8 AData, const u8 ALen) { try { // 自定义函数: 
 // return IDX_ERR_OK;
u8 crc = 0x11; 
u8 byte_index; 
u8 bit_index;
// CRC8 demo 

crc = *(AData + 1)^*(AData + 2)^*(AData + 3)^*(AData + 4)^*(AData + 5)^*(AData + 6)^*(AData + 7)+0x10;	
//crc =    *(AData + 7);
return crc;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); return(IDX_ERR_MP_CODE_CRASH); }}
// CODE BLOCK END Custom_Function MakeCheckSum_0xF8

// CODE BLOCK BEGIN Custom_Function MakeCheckSum_0xFC Y29uc3QgcHU4IEFEYXRhLCBjb25zdCB1OCBBTGVu
// 自定义函数 "MakeCheckSum_0xFC"
s32 MakeCheckSum_0xFC(const pu8 AData, const u8 ALen) { try { // 自定义函数: 
 // return IDX_ERR_OK;
u8 crc = 0x11; 
u8 byte_index; 
u8 bit_index;
// CRC8 demo 

crc = *(AData + 1)^*(AData + 2)^*(AData + 3)^*(AData + 4)^*(AData + 5)^*(AData + 6)^*(AData + 7)+0x10;	
//crc =    *(AData + 7);
return crc;

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); return(IDX_ERR_MP_CODE_CRASH); }}
// CODE BLOCK END Custom_Function MakeCheckSum_0xFC

// CODE BLOCK BEGIN Step_Function  NQ__
// 主step函数，执行周期 5 ms
void step(void) { try { // 周期 = 5 ms

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END Step_Function 

