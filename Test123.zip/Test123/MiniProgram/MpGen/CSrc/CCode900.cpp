﻿// GEN BLOCK BEGIN Include
#define TSMP_IMPL
#include "TSMaster.h"
#include "MPLibrary.h"
#include "Database.h"
#include "TSMasterBaseInclude.h"
#include "Configuration.h"
// GEN BLOCK END Include

// GEN BLOCK BEGIN Custom_Function
s32 MakeCheckSum(const pu8 AData, const u8 ALen);
// GEN BLOCK END Custom_Function

// CODE BLOCK BEGIN On_CAN_PreTx NewOn_CAN_PreTx1 MCwtMSwyNDg_
// CAN报文预发送事件 "NewOn_CAN_PreTx1" 针对标识符 = 0xF8
void on_can_pretx_NewOn_CAN_PreTx1(const PCAN ACAN) { try {  // 针对标识符 = 0xF8
// if (ACAN->FIdxChn != CH1) return; // if you want to filter channel
THCU_1_6_1 HCU_1_6_1;
HCU_1_6_1.init(); // 在使用此结构体前调用这段初始化代码
HCU_1_6_1.FCAN = *ACAN; // 若是在回调函数中，请用ACAN数据赋值FCAN
// deal with signals using HCU_1_6_1.XXX

//HCU_1_6_1.Checksum_HCU_1_6=ACAN->FCAN[1]^ACAN->FCAN[2]^ACAN->FCAN[3]^ACAN->FCAN[4]^ACAN->FCAN[5]^ACAN->FCAN[6]^ACAN->FCAN[7];
//HCU_1_6_1.Checksum_HCU_1_6=9;
HCU_1_6_1.Checksum_HCU_1_6=MakeCheckSum(&HCU_1_6_1.FCAN.FData[0], 8); 
*ACAN = HCU_1_6_1.FCAN;
} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END On_CAN_PreTx NewOn_CAN_PreTx1

// CODE BLOCK BEGIN Custom_Function MakeCheckSum Y29uc3QgcHU4IEFEYXRhLCBjb25zdCB1OCBBTGVu
// 自定义函数 "MakeCheckSum"
s32 MakeCheckSum(const pu8 AData, const u8 ALen) { try { // 自定义函数: 
 // return IDX_ERR_OK;
u8 crc = 0xFF; 
u8 byte_index; 
u8 bit_index;
// CRC8 demo 

crc = *(AData + 1)^*(AData + 2)^*(AData + 3)^*(AData + 4)^*(AData + 5)^*(AData + 6)^*(AData + 7);	
print
return crc;
} catch (...) { log_nok("CRASH detected"); app.terminate_application(); return(IDX_ERR_MP_CODE_CRASH); }}
// CODE BLOCK END Custom_Function MakeCheckSum

// CODE BLOCK BEGIN Step_Function  NQ__
// 主step函数，执行周期 5 ms
void step(void) { try { // 周期 = 5 ms

} catch (...) { log_nok("CRASH detected"); app.terminate_application(); }}
// CODE BLOCK END Step_Function 

