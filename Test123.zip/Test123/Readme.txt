This is a TSMaster project directory
To save this project as a single file for configuration exchange, you can:
  [1] Click "Export Project" button in toolbar
  [2] Select ".T7z" file type for 7zip compression support
  [3] or Select ".PT7z" file type for password protected 7zip support, and provide your password when this configuration is being loaded on other machines
To publish or deliver this project with custom plugins, you need to:
  [1] copy your bpl into Plugins\External\xxx.bpl
  [2] copy your dependencies (*.dll, *.bpl, etc) into Plugins\Dependencies\xxx.dll
  [3] TSMaster will automatically handle all needed files during project loading
